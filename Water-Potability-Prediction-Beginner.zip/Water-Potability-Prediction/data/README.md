# Dataset

Download `water_potability.csv` from the public Kaggle Water Potability dataset:

https://www.kaggle.com/datasets/adityakadiwal/water-potability

Place the downloaded file in this folder.

Do not upload sensitive/private datasets to GitHub.
